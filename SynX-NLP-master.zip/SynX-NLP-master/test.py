import SynXNLP as s

s.analysis('D:/test.txt')
